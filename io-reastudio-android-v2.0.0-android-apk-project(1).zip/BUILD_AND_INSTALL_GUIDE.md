# Build & Install REA Studio APK (Zero AI Credits Required)

- **App Name**: REA Studio
- **Package ID**: `io.reastudio.android`
- **Version**: 2.0.0 (versionCode 2)
- **Compatibility**: Android 8.0 (API 26) through Android 14 (API 34)
- **Project Archive**: `io-reastudio-android-v2.0.0-android-apk-project.zip`
- **Project Type**: Native Kotlin WebView Wrapper with APK/XAPK file chooser and MediaStore download bridge
- **Included Free Build Tools**: `build-apk.sh`, `build-apk.bat`, `.github/workflows/build-apk.yml`, `AGENTS.md`

> **Out of Antigravity AI credits?** You do **not** need AI credits to compile or install your APK. Use **Antigravity's built-in Terminal** (Option A) or **GitHub Actions Free Cloud Build** (Option B) — both cost **0 credits**.

---

## Part 1: Finish Building the APK (0 AI Credits)

### Option A: Inside Google Antigravity’s Built-In Terminal (0 Credits)
You can keep using the exact Antigravity window you already have open — just use its **Terminal** instead of Agent Chat.

1. **Open the Project Folder**: Unzip `io-reastudio-android-v2.0.0-android-apk-project.zip` and open `io-reastudio-android-v2.0.0-android-apk-project` in **Google Antigravity** (**File -> Open Folder…**).
2. **Open the Built-In Terminal (Free)**: Press `Ctrl + `` (backtick) or choose **Terminal -> New Terminal** in the top menu.
3. **Run the Included One-Command Builder**:
   - **macOS / Linux**:
     ```bash
     bash build-apk.sh
     ```
   - **Windows**:
     ```cmd
     build-apk.bat
     ```
   *The script automatically detects your Android SDK, creates `local.properties`, downloads Gradle 8.7 locally if not installed, and compiles `app/build/outputs/apk/debug/app-debug.apk`.*

---

### Option B: 100% Free Cloud Build on GitHub Actions (No Local SDK or Credits Needed)
If your computer doesn't have Java 17 or the Android SDK installed, let GitHub's free tier compile the APK in the cloud (~2 minutes):

1. Unzip `io-reastudio-android-v2.0.0-android-apk-project.zip` into `io-reastudio-android-v2.0.0-android-apk-project` (make sure `.github/workflows/build-apk.yml` sits in the root).
2. Push to a new GitHub repository (or upload via GitHub web UI):
   ```bash
   cd io-reastudio-android-v2.0.0-android-apk-project
   git init
   git add .
   git commit -m "Initial REA Studio Android project"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. Open your GitHub repo -> **Actions** tab -> **Build Android Debug APK** -> wait for the green checkmark.
4. Download the **rea-studio-debug-apk** artifact ZIP and unzip it to get `app-debug.apk`.

---

## Part 2: Install the APK onto Your Android Phone (0 Credits)

### Option 1: Direct Sideload on Your Phone (No USB Cable)
1. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone (or download the GitHub Actions artifact directly on your phone and unzip it).
2. Open your phone's **Files** app -> **Downloads** -> tap `app-debug.apk`.
3. If prompted *"Your phone isn't allowed to install unknown apps"*, tap **Settings -> Allow from this source**, press Back, and tap **Install**.
4. If Google Play Protect prompts because it's a self-built debug APK, tap **More details -> Install anyway**, then **Open**.

### Option 2: Install via USB inside Antigravity’s Terminal (ADB)
1. On your phone: **Settings -> About phone -> tap Build number 7 times** -> **Developer options -> USB debugging ON**.
2. Plug your phone in via USB and tap **Allow**.
3. Run in Antigravity's Terminal (0 credits):
   ```bash
   adb devices
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   adb shell monkey -p io.reastudio.android -c android.intent.category.LAUNCHER 1
   ```

### Option 3: Wireless Debugging via Terminal (Android 11+)
1. Enable **Developer options -> Wireless debugging -> Pair device with pairing code**.
2. Run in Antigravity's Terminal:
   ```bash
   adb pair PHONE_IP:PAIR_PORT
   adb connect PHONE_IP:MAIN_PORT
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

## Troubleshooting

- **Antigravity says "Not enough credits"**: Only the AI Agent Chat panel consumes credits. Close Agent Chat and use **Terminal -> New Terminal** (`Ctrl + ``) to run `bash build-apk.sh` (Mac/Linux) or `build-apk.bat` (Windows) for free — or use **GitHub Actions** in the cloud for free.
- **`build-apk.sh` says Android SDK or Java 17 not found**: Switch to **Option B (GitHub Actions Cloud Build)** — GitHub installs JDK 17 and Android SDK 34 automatically for free in ~2 minutes.
- **“App not installed as package conflicts with an existing package”**: Uninstall any previous version of `io.reastudio.android` on your phone (or run `adb uninstall io.reastudio.android`) and reinstall.
- **“There was a problem parsing the package”**: Make sure you unzipped the GitHub artifact to get `app-debug.apk` and your phone runs Android 8.0 (API 26) or newer.
