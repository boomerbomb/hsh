#!/usr/bin/env bash
set -euo pipefail

APP_NAME="REA Studio"
PKG_NAME="io.reastudio.android"
GRADLE_VER="8.7"

echo "=================================================="
echo " Building $APP_NAME ($PKG_NAME) - 0 AI Credits"
echo "=================================================="

# 1. Check Java 17+
if ! command -v java >/dev/null 2>&1; then
  echo ""
  echo "[ERROR] Java (JDK 17) is not installed or not in PATH."
  echo "Install Temurin JDK 17 from https://adoptium.net/ or use the free GitHub Actions build."
  exit 1
fi
echo "[OK] Java detected:"
java -version 2>&1 | head -n 1

# 2. Detect Android SDK and write local.properties if missing
SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK_DIR" ]; then
  for CANDIDATE in "$HOME/Library/Android/sdk" "$HOME/Android/Sdk" "/usr/local/share/android-sdk"; do
    if [ -d "$CANDIDATE" ]; then
      SDK_DIR="$CANDIDATE"
      break
    fi
  done
fi

if [ -n "$SDK_DIR" ] && [ -d "$SDK_DIR" ]; then
  export ANDROID_HOME="$SDK_DIR"
  if [ ! -f "local.properties" ]; then
    echo "sdk.dir=$SDK_DIR" > local.properties
    echo "[OK] Created local.properties pointing to $SDK_DIR"
  fi
elif [ ! -f "local.properties" ]; then
  echo ""
  echo "[ERROR] Android SDK not found (ANDROID_HOME is empty and no local.properties)."
  echo "Tip: Install Android Studio / Android Command-Line Tools, OR push this folder to GitHub"
  echo "and run Actions -> Build Android Debug APK for a 100% free cloud build (no local SDK needed)."
  exit 1
fi

# 3. Locate Gradle (./gradlew -> global gradle -> auto-download Gradle 8.7 locally)
GRADLE_CMD=""
if [ -x "./gradlew" ]; then
  GRADLE_CMD="./gradlew"
elif command -v gradle >/dev/null 2>&1; then
  GRADLE_CMD="gradle"
else
  LOCAL_GRADLE_BIN=".gradle-local/gradle-$GRADLE_VER/bin/gradle"
  if [ ! -x "$LOCAL_GRADLE_BIN" ]; then
    echo "[INFO] Gradle not found globally. Downloading Gradle $GRADLE_VER locally..."
    mkdir -p .gradle-local
    curl -fSL "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip" -o ".gradle-local/gradle.zip"
    unzip -q -o ".gradle-local/gradle.zip" -d .gradle-local
    rm -f ".gradle-local/gradle.zip"
  fi
  GRADLE_CMD="$LOCAL_GRADLE_BIN"
fi

echo "[INFO] Compiling debug APK with $GRADLE_CMD..."
"$GRADLE_CMD" assembleDebug --no-daemon

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
  echo ""
  echo "=================================================="
  echo " BUILD SUCCESSFUL!"
  echo " APK: $APK_PATH"
  echo "=================================================="
  if command -v adb >/dev/null 2>&1 && adb devices | grep -q "device$"; then
    echo ""
    echo "[INFO] Android device detected via ADB. Installing & launching..."
    adb install -r "$APK_PATH"
    adb shell monkey -p "$PKG_NAME" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 || true
    echo "[OK] Installed and launched $APP_NAME!"
  else
    echo ""
    echo "Next step: Copy $APK_PATH to your Android phone and tap it to install,"
    echo "or plug in your phone with USB Debugging enabled and run:"
    echo "  adb install -r $APK_PATH"
  fi
else
  echo "[ERROR] Build finished but $APK_PATH was not found."
  exit 1
fi
