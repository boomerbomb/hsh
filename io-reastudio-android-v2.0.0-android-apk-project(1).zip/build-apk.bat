@echo off
setlocal enabledelayedexpansion

set "APP_NAME=REA Studio"
set "PKG_NAME=io.reastudio.android"
set "GRADLE_VER=8.7"

echo ==================================================
echo  Building %APP_NAME% (%PKG_NAME%) - 0 AI Credits
echo ==================================================

where java >nul 2>&1
if errorlevel 1 (
  echo.
  echo [ERROR] Java (JDK 17) is not installed or not in PATH.
  echo Install Temurin JDK 17 from https://adoptium.net/ or use the free GitHub Actions build.
  exit /b 1
)

set "SDK_DIR=%ANDROID_HOME%"
if "%SDK_DIR%"=="" set "SDK_DIR=%ANDROID_SDK_ROOT%"
if "%SDK_DIR%"=="" if exist "%LOCALAPPDATA%\Android\Sdk" set "SDK_DIR=%LOCALAPPDATA%\Android\Sdk"

if not "%SDK_DIR%"=="" (
  set "ANDROID_HOME=%SDK_DIR%"
  if not exist "local.properties" (
    set "ESCAPED_SDK=%SDK_DIR:\=\\%"
    set "ESCAPED_SDK=!ESCAPED_SDK::=\:!"
    echo sdk.dir=!ESCAPED_SDK!> local.properties
    echo [OK] Created local.properties pointing to %SDK_DIR%
  )
) else if not exist "local.properties" (
  echo.
  echo [ERROR] Android SDK not found ^(ANDROID_HOME is empty and no local.properties^).
  echo Tip: Install Android Studio / Android SDK, OR push this folder to GitHub
  echo and run Actions -^> Build Android Debug APK for a 100%% free cloud build.
  exit /b 1
)

set "GRADLE_CMD="
if exist "gradlew.bat" (
  set "GRADLE_CMD=gradlew.bat"
) else (
  where gradle >nul 2>&1
  if not errorlevel 1 (
    set "GRADLE_CMD=gradle"
  ) else (
    set "LOCAL_GRADLE=.gradle-local\gradle-%GRADLE_VER%\bin\gradle.bat"
    if not exist "!LOCAL_GRADLE!" (
      echo [INFO] Downloading Gradle %GRADLE_VER% locally...
      if not exist ".gradle-local" mkdir .gradle-local
      powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VER%-bin.zip' -OutFile '.gradle-local\gradle.zip'; Expand-Archive -Path '.gradle-local\gradle.zip' -DestinationPath '.gradle-local' -Force; Remove-Item '.gradle-local\gradle.zip'"
    )
    set "GRADLE_CMD=!LOCAL_GRADLE!"
  )
)

echo [INFO] Compiling debug APK with %GRADLE_CMD%...
call "%GRADLE_CMD%" assembleDebug --no-daemon
if errorlevel 1 exit /b 1

set "APK_PATH=app\build\outputs\apk\debug\app-debug.apk"
if exist "%APK_PATH%" (
  echo.
  echo ==================================================
  echo  BUILD SUCCESSFUL!
  echo  APK: %APK_PATH%
  echo ==================================================
  echo Copy %APK_PATH% to your phone to install, or run:
  echo   adb install -r %APK_PATH%
) else (
  echo [ERROR] Build finished but %APK_PATH% was not found.
  exit /b 1
)
