# REA Studio — Android APK Wrapper Project

- **Package ID**: `io.reastudio.android`
- **Version**: `2.0.0` (`versionCode=2`)
- **Workbench URL**: https://ais-dev-4glrxcxosfahw2xxltb456-920378276343.us-east1.run.app

## Build Your APK with Zero AI Credits
1. **Inside Antigravity’s Terminal** (`Ctrl + `` — uses 0 AI credits): run `bash build-apk.sh` (macOS/Linux) or `build-apk.bat` (Windows).
2. **Or Free GitHub Cloud Build (No Local SDK Needed)**: push to GitHub -> **Actions -> Build Android Debug APK** -> download `app-debug.apk`.

See **[BUILD_AND_INSTALL_GUIDE.md](./BUILD_AND_INSTALL_GUIDE.md)** for full step-by-step build & Android install instructions.
