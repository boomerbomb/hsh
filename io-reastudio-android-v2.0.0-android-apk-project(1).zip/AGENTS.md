# AGENTS.md — REA Studio (Android Project)

This file provides workspace instructions for **Google Antigravity** agents (or local developers) working on **REA Studio**.

## Project Metadata
- **App Name**: REA Studio
- **Application ID / Namespace**: `io.reastudio.android`
- **Version**: `2.0.0` (`versionCode = 2`)
- **SDK Targets**: `minSdk = 26`, `compileSdk = 34`, `targetSdk = 34`
- **Toolchain**: Gradle 8.7 (Kotlin DSL), AGP 8.5.2, Kotlin 2.0.20, JDK 17

## Architecture Rules
- **Architecture**: Kotlin WebView wrapper (`MainActivity.kt`) hosting the live REA Studio web workbench with native `onShowFileChooser` (`.apk/.xapk/.json` picker) and `MediaStore` download bridge.
- Do not remove `ReaDownloadBridge` or `onShowFileChooser` when modifying `MainActivity.kt`.
- Never commit or expose `local.properties`, `*.jks`, or `*.keystore` files (excluded via `.aiexclude`).

## Zero-Credit Local Build Scripts
- macOS / Linux: `bash build-apk.sh`
- Windows: `build-apk.bat`
- Expected APK output: `app/build/outputs/apk/debug/app-debug.apk`
